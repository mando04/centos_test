# This is the configuration file for the mail import client

# This secret has to be known by the wiki server
mail_import_secret = "use same string as in secrets setting in wiki config"

# The target wiki URL
mail_import_url = u"http://localhost/?action=xmlrpc2"

