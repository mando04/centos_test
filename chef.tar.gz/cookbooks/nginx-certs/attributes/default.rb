default['nginx']['ssl_dir']      = "#{node['nginx']['conf_dir']}/ssl"
default['nginx-certs']['C']		 = "US"
default['nginx-certs']['ST']	 = "TX"
default['nginx-certs']['L']		 = "Dallas"
default['nginx-certs']['O']		 = "Nothing"
default['nginx-certs']['OU']	 = "Best eva"
default['nginx-certs']['CN']	 = "Best eva PROD"
default['nginx-certs']['email']	 = "root@localhost"

