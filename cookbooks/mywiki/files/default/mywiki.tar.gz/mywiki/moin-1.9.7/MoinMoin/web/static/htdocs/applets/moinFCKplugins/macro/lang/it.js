﻿FCKLang.MacroBtn			= 'Aggiungi/Modifica Macro' ;
FCKLang.MacroDlgTitle		= 'Proprietà del Macro' ;
FCKLang.MacroDlgName		= 'Nome del Macro' ;
FCKLang.MacroErrNoName	= 'Digitare il nome del macro' ;
FCKLang.MacroErrNameInUse	= 'Il nome inserito è già in uso' ;
