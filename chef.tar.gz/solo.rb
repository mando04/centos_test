cookbook_path [
  "/var/chef/cookbooks",
  "/var/chef/site-cookbooks",
  "/etc/chef/cookbooks"
]
verbose_logging true
