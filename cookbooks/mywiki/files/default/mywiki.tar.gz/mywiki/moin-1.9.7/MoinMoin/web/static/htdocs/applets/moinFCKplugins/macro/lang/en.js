﻿FCKLang.MacroBtn			= 'Insert/Edit Macro' ;
FCKLang.MacroDlgTitle		= 'Macro Properties' ;
FCKLang.MacroDlgName		= 'Macro Name' ;
FCKLang.MacroErrNoName	= 'Please type the macro name' ;
FCKLang.MacroErrNameInUse	= 'The specified name is already in use' ;
