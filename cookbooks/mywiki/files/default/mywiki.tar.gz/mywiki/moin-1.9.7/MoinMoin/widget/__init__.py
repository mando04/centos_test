# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - Interface Widgets

    @copyright: 2002 Juergen Hermann <jh@web.de>
    @license: GNU GPL, see COPYING for details.
"""

